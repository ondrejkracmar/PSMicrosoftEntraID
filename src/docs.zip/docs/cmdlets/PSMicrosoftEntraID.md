﻿---
Module Name: PSMicrosoftEntraID
Module Guid: 3ccc09a2-90bd-4561-9069-6db4040ff4f7
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# PSMicrosoftEntraID Module
## Description
{{ Fill in the Description }}

## PSMicrosoftEntraID Cmdlets
### [Add-PSEntraIDGroupMember](Add-PSEntraIDGroupMember.md)
{{ Fill in the Description }}

### [Add-PSEntraIDGroupOwner](Add-PSEntraIDGroupOwner.md)
{{ Fill in the Description }}

### [Compare-PSEntraIDUserList](Compare-PSEntraIDUserList.md)
{{ Fill in the Description }}

### [Connect-PSMicrosoftEntraID](Connect-PSMicrosoftEntraID.md)
{{ Fill in the Description }}

### [Disable-PSEntraIDUserLicense](Disable-PSEntraIDUserLicense.md)
{{ Fill in the Description }}

### [Disable-PSEntraIDUserLicenseServicePlan](Disable-PSEntraIDUserLicenseServicePlan.md)
{{ Fill in the Description }}

### [Enable-PSEntraIDUserLicense](Enable-PSEntraIDUserLicense.md)
{{ Fill in the Description }}

### [Enable-PSEntraIDUserLicenseServicePlan](Enable-PSEntraIDUserLicenseServicePlan.md)
{{ Fill in the Description }}

### [Get-PSEntraIDGroup](Get-PSEntraIDGroup.md)
{{ Fill in the Description }}

### [Get-PSEntraIDGroupMember](Get-PSEntraIDGroupMember.md)
{{ Fill in the Description }}

### [Get-PSEntraIDLicenseIdentifier](Get-PSEntraIDLicenseIdentifier.md)
{{ Fill in the Description }}

### [Get-PSEntraIDOrganization](Get-PSEntraIDOrganization.md)
{{ Fill in the Description }}

### [Get-PSEntraIDSubscribedLicense](Get-PSEntraIDSubscribedLicense.md)
{{ Fill in the Description }}

### [Get-PSEntraIDUsageLocation](Get-PSEntraIDUsageLocation.md)
{{ Fill in the Description }}

### [Get-PSEntraIDUser](Get-PSEntraIDUser.md)
{{ Fill in the Description }}

### [Get-PSEntraIDUserLicense](Get-PSEntraIDUserLicense.md)
{{ Fill in the Description }}

### [Get-PSEntraIDUserLicenseDetail](Get-PSEntraIDUserLicenseDetail.md)
{{ Fill in the Description }}

### [Get-PSEntraIDUserMemberOf](Get-PSEntraIDUserMemberOf.md)
{{ Fill in the Description }}

### [Get-ServiceCompletion](Get-ServiceCompletion.md)
{{ Fill in the Description }}

### [New-PSEntraIDGroup](New-PSEntraIDGroup.md)
{{ Fill in the Description }}

### [New-PSEntraIDInvitation](New-PSEntraIDInvitation.md)
{{ Fill in the Description }}

### [Remove-PSEntraIDGroup](Remove-PSEntraIDGroup.md)
{{ Fill in the Description }}

### [Remove-PSEntraIDGroupMember](Remove-PSEntraIDGroupMember.md)
{{ Fill in the Description }}

### [Remove-PSEntraIDGroupOwner](Remove-PSEntraIDGroupOwner.md)
{{ Fill in the Description }}

### [Remove-PSEntraIDUser](Remove-PSEntraIDUser.md)
{{ Fill in the Description }}

### [Set-PSEntraIDGroup](Set-PSEntraIDGroup.md)
{{ Fill in the Description }}

### [Set-PSEntraIDUserUsageLocation](Set-PSEntraIDUserUsageLocation.md)
{{ Fill in the Description }}

### [Sync-PSEntraIDGroupMember](Sync-PSEntraIDGroupMember.md)
{{ Fill in the Description }}

